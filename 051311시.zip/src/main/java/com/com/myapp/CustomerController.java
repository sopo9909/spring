package com.com.myapp;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class CustomerController {
	//서비스를 호출하기 위해 CustomerService를 의존성을 주입.
	@Autowired
	CustomerService customerService;
	// /라는 곳으로 들어가면 ModelAndView에서의 Home을 실행한다. 이는 결과값을 main이라는 jsp를 실행시켜준다.
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView Home() {
		return new ModelAndView("/customer/main");
	}
	//브라우저 주소가 /create 일 때, 실행되는 자바 컨트롤러 메소드를 작성
	//브라우저 주소가 GET 방식으로 입력되었을 때, /customer/create의 jsp 경로의 뷰를 보여준다
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public ModelAndView Create() {
		return new ModelAndView("/customer/create");
	}
	//입력 후 저장 버튼을 누르면, 서버가 해야 하는 일을 정의하는 것
	//RequestParam을 통해 쿼리 스트링 파라미터를 읽을 수 있게 한다.
	//Map 인터페이스는 (key:value)형식의 저장 방식을 사용함.
	//Key의 경우는 값을 저장하고 가져오기 위한 유일한 열쇠이며, value의 경우는 key에 종속된 데이터이다.
	//키의 경우는 중복이 허용되지 않고 Value의 경우는 허용한다.
	//가장 많이 사용하는 형태는 Map<K,V>으로 HashMap의 경우 key:value를 묶어 하나의 Entry형식으로 저장.
	//Map<String,Object>는 Map을 선언하는 것이다.
	//object는 변수가 아니라 그냥 모든 자료형을 언급한다.
	//map.get("X").toString();은 map 데이터를 문자열에 셋팅
	@RequestMapping(value="/create",method = RequestMethod.POST)
	public ModelAndView createPost(@RequestParam Map<String, Object> map) {
		ModelAndView mav = new ModelAndView();
		//생성을 하면 그거의 생성된 id를 가져온다. 그를 통해 디테일로 넘겨준다.
		String id = this.customerService.create(map);
		if(id==null) {
			mav.setViewName("redirect:/create");
		}else {
			mav.setViewName("redirect:/detail?id="+id);
		}
		//mav를 실행시킨다.
		return mav;
	}
	
	@RequestMapping(value ="/detail",method=RequestMethod.GET)
	public ModelAndView detail(@RequestParam Map<String, Object>map) {
		// Map형태로 오니까 detailMap이라고 변수를 만들어준다.
		Map<String, Object> detailMap = this.customerService.detail(map);
		ModelAndView mav = new ModelAndView();
		mav.addObject("data",detailMap);
		String id = map.get("id").toString();
		mav.addObject("id",id);
		mav.setViewName("/customer/detail");
		return mav;
	}
	
//이거 새로하는 count
	@RequestMapping(value ="/count",method=RequestMethod.GET)
	public ModelAndView count(@RequestParam Map<String, Object>map) {
		Map<String, Object> detailMap = this.customerService.count(map);
		ModelAndView mav = new ModelAndView();
		//String tot = this.customerService.count(map);
		mav.addObject("tata",detailMap);
		mav.setViewName("/customer/count");
		return mav;
	}
//여기까지
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public ModelAndView update(@RequestParam Map<String,Object>map) {
		Map<String,Object> detailMap = this.customerService.detail(map);
		ModelAndView mav = new ModelAndView();
		mav.addObject("data",detailMap);
		mav.setViewName("/customer/update");
		return mav;
	}
	
	@RequestMapping(value ="/update",method =RequestMethod.POST)
	public ModelAndView updatePost(@RequestParam Map<String, Object>map) {
		ModelAndView mav = new ModelAndView();
		boolean isUpdateSuccess = this.customerService.edit(map);
		if(isUpdateSuccess) {
			String id = map.get("id").toString();
			mav.setViewName("redirect:/detail?id="+id);
		}else {
			mav = this.update(map);
		}
		return mav;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)  
	public ModelAndView deletePost(@RequestParam Map<String, Object> map) {  
		ModelAndView mav = new ModelAndView();  
	
		boolean isDeleteSuccess = this.customerService.remove(map);  
		if (isDeleteSuccess) {  
			mav.setViewName("redirect:/list");  
		}else {  
			String id = map.get("id").toString();  
			mav.setViewName("redirect:/detail?id=" + id);  
		}  
		return mav;  
	}
	
	@RequestMapping(value = "/list")  
	public ModelAndView list(@RequestParam Map<String, Object> map) {  
		List<Map<String, Object>> list = this.customerService.list(map);  
		ModelAndView mav = new ModelAndView();  
		mav.addObject("data", list);  
		mav.setViewName("/customer/list");  
		return mav;  
	}
	
	@RequestMapping(value = "/search")  
	public ModelAndView search(@RequestParam Map<String, Object> map) {  
		List<Map<String, Object>> list = this.customerService.search(map);  
		ModelAndView mav = new ModelAndView();  
		mav.addObject("data", list);  
		if(map.containsKey("keyword")) {
			mav.addObject("keyword",map.get("keyword"));
		}
		mav.setViewName("/customer/search");  
		return mav;  
	}  
	
	@RequestMapping(value = "/search2")  
	public ModelAndView search2(@RequestParam Map<String, Object> map) {  
		List<Map<String, Object>> list = this.customerService.search2(map);  
		ModelAndView mav = new ModelAndView();  
		mav.addObject("data", list);  
		if(map.containsKey("keyword2")) {
			mav.addObject("keyword2",map.get("keyword2"));
		}
		mav.setViewName("/customer/search2");  
		return mav;  
	} 
	
	@RequestMapping(value = "/search3")  
	public ModelAndView search3(@RequestParam Map<String, Object> map) {  
		List<Map<String, Object>> list = this.customerService.search3(map);  
		ModelAndView mav = new ModelAndView();  
		mav.addObject("data", list);  
		if(map.containsKey("keyword3")) {
			mav.addObject("keyword3",map.get("keyword3"));
		}
		mav.setViewName("/customer/search3");  
		return mav;  
	} 

}